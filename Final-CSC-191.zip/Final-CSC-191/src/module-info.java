/**
 * 
 */
/**
 * @author hunterallen
 *
 */
module com.FinalCSC191 {
	requires java.desktop;
	requires java.compiler;
}