package mainPackage;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.print.DocFlavor.URL;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.tools.*;

import org.json.simple.parser.JSONParser;

import java.awt.BorderLayout;

//import org.json.simple.parser.JSONParser;

import java.awt.Color;
import java.awt.Desktop.Action;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JToggleButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.io.FileReader;
import java.util.Iterator;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
//import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import com.google.gson.*;
//import java.lang.module.Configuration;

//Error: Could not find or load main class org.xmlpull.v1.dom2_builder.DOM2XmlPullBuilder in module com.FinalCSC191
	
public class mainWindow {

	private JFrame frame;
	static JTextField textField;
	static JButton runBtn;
	static JTextArea textArea;
	static JLabel titleLabel;
	static JLabel levelBtn;
	static JButton restartBtn;
	static JButton skipBtn;
	static int level = 0;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainWindow window = new mainWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public mainWindow() {
		initialize();
		StartGame();
		
		readJsonFile();
		
	}
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 0, 0));
		frame.setBounds(100, 100, 800, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		runBtn = new JButton("Run");
		runBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Run();
			}
		});
		runBtn.setFont(new Font("American Typewriter", Font.PLAIN, 20));
		runBtn.setForeground(new Color(0, 128, 0));
		runBtn.setBackground(Color.WHITE);
		runBtn.setBounds(285, 531, 226, 43);
		frame.getContentPane().add(runBtn);
		
		textField = new JTextField();
		textField.setBackground(new Color(255, 255, 255));
		textField.setBounds(6, 482, 788, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("American Typewriter", Font.PLAIN, 15));
		textArea.setForeground(new Color(0, 128, 0));
		textArea.setBackground(Color.WHITE);
		textArea.setBounds(6, 52, 788, 413);
		frame.getContentPane().add(textArea);
		
		titleLabel = new JLabel("Hacker Run");
		titleLabel.setFont(new Font("American Typewriter", Font.PLAIN, 20));
		titleLabel.setForeground(new Color(50, 205, 50));
		titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
		titleLabel.setBounds(162, 7, 462, 29);
		frame.getContentPane().add(titleLabel);
		
		levelBtn = new JLabel("Level 0");
		levelBtn.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		levelBtn.setHorizontalAlignment(SwingConstants.CENTER);
		levelBtn.setForeground(new Color(255, 255, 255));
		levelBtn.setBounds(691, 5, 89, 35);
		frame.getContentPane().add(levelBtn);
		
		restartBtn = new JButton("Restart");
		restartBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				RestartGame();
			}
		});
		restartBtn.setFont(new Font("American Typewriter", Font.PLAIN, 20));
		restartBtn.setForeground(new Color(0, 128, 0));
		restartBtn.setBounds(22, 614, 226, 43);
		frame.getContentPane().add(restartBtn);
		
		skipBtn = new JButton("Skip Level");
		skipBtn.setForeground(new Color(0, 128, 0));
		skipBtn.setFont(new Font("American Typewriter", Font.PLAIN, 20));
		skipBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SkipLevel();
			}
		});
		skipBtn.setBounds(554, 619, 226, 39);
		frame.getContentPane().add(skipBtn);
	}
	
	public static void RestartGame() {
		level = 0;
		textField.setText("");
		levelBtn.setText("Level " + level);
		
	}

	public static void StartGame() {
		level = 0;
		textField.setText("");
		levelBtn.setText("Level " + level);
		
	}
	
	public static void SkipLevel() {
		if (level == 10) {
			FinishedGame();
			JOptionPane.showMessageDialog(null, "You've Reach the Maximun Level", "Ok", JOptionPane.INFORMATION_MESSAGE);
		} else {
			level += 1;
			textField.setText("");
			levelBtn.setText("Level " + level);
		}
	}
	
	public static void FinishedGame() {
		new gifTimer();
	}
	
	
    public static void ShowFinishedGIF1() {
		
		Icon icon = new ImageIcon("/Users/hunterallen/Desktop/Final-CSC-191/Finished.gif");
		JLabel label = new JLabel(icon);
		JFrame f = new JFrame("Animation");
		f.getContentPane().add(label);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
	
	public static void ShowFinishedGIF2() {
		Icon icon = new ImageIcon("/Users/hunterallen/Desktop/Final-CSC-191/Finished2.gif");
		JLabel label = new JLabel(icon);
		JFrame f = new JFrame("Animation");
		f.getContentPane().add(label);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
	
	public static void ShowFinishedGIF3() {
		Icon icon = new ImageIcon("/Users/hunterallen/Desktop/Final-CSC-191/Finished3.gif");
		JLabel label = new JLabel(icon);
		JFrame f = new JFrame("Animation");
		f.getContentPane().add(label);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
	
	public static void readJsonFile() {
//"/Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.json"
        BufferedReader br = null;
        JSONParser parser = new JSONParser();

        try {

            String sCurrentLine;

            br = new BufferedReader(new FileReader("D:\\example.json"));

            while ((sCurrentLine = br.readLine()) != null) {
                System.out.println("Record:\t" + sCurrentLine);

//                Object obj;
//                try {
//                    obj = parser.parse(sCurrentLine);
//                    JSONObject jsonObject = (JSONObject) obj;
//
//                    String rel = (String) jsonObject.get("rel");
//                    System.out.println(rel);
//
//                    String start = (String) jsonObject.get("start");
//                    System.out.println(start);
//
//                    String end = (String) jsonObject.get("end");
//                    System.out.println(end);
//
//                } catch (ParseException e) {
//                    // TODO Auto-generated catch block
//                    e.printStackTrace();
//                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null)br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
	
	public static void ReadAnswerFile() {
		//System.out.format("Task scheduled..!%n \n");
		
//		//"c:/Final-CSC-191/src/answers/answers.java"
//	//	/Users/HunterAllen/Desktop/Final-CSC-191/src/answers/answers.java"
//		//"c:/answers.java"
//		//System.out.println(openFile.getAbsolutePath());
//		System.out.print(System.getProperty("user.dir"));//  /Users/hunterallen/Desktop/Final-CSC-191
///Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.java
		
		
//		FileReader reader = null;
//		try {
//			reader = new FileReader(new File("/Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.json"));
//		} catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//			System.out.println("error here");
//		}
////
//
//	    JSONParser jsonParser = new JSONParser();
//	    JSONArray jsonArray = null;
//		try {
//			jsonArray = (JSONArray) jsonParser.parse(reader);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			System.out.println("error here2");
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			System.out.println("error here3");
//		}
//	    JSONObject object = (JSONObject) jsonArray.get(0);
//	    long elementaryProductId = (Long) object.get("elementaryProductId");
////
////
////
//	    System.out.println("The id is: " + elementaryProductId);
	    
	    
		
		
		
	    ///
	    
	    JSONParser jsonParser2 = new JSONParser();
	    JSONArray a = null;
		try {
			
			a = (JSONArray) jsonParser2.parse(new FileReader("/Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.json"));//"c:\\answers.json"
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error here6");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error here5");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("error here4");
		}
	    		
//	    try {
//			System.out.println(new FileReader("/Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.java"));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	    
//	    JSONParser parser = new JSONParser();
//	    try {
//			Object obj = parser.parse(new FileReader("/Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.java"));
//		} catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		} catch (ParseException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
	    
//		try {
//			JSONObject my = (JSONObject) jsonParser2.parse(new InputStreamReader(new FileInputStream("/Users/hunterallen/Desktop/Final-CSC-191/src/answers/answers.java")));
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	    for (Object o : a) {
	      JSONObject person = (JSONObject) o;

	      String name = (String) person.get("level");
	      System.out.println(name);

//	      String city = (String) person.get("city");
//	      System.out.println(city);
//
//	      String job = (String) person.get("job");
//	      System.out.println(job);

	      JSONArray cars = (JSONArray) person.get("cars");

	      for (Object c : cars)
	      {
	        System.out.println(c+"");
	      }
	    }
	    
	    
	    
	    
	    
	    ///
	    
//	 // parsing file "JSONExample.json" 
//        Object obj = new JSONParser().parse(new FileReader("JSONExample.json")); 
//          
//        // typecasting obj to JSONObject 
//        JSONObject jo = (JavaFileObject) obj; 
//          
//        // getting firstName and lastName 
//        String firstName = (String) jo.get("firstName"); 
//        String lastName = (String) jo.get("lastName"); 
//          
//        System.out.println(firstName); 
//        System.out.println(lastName); 
//          
//        // getting age 
//        long age = (long) jo.get("age"); 
//        System.out.println(age); 
//          
//        // getting address 
//        Map address = ((Map)jo.get("address")); 
//          
//        // iterating address Map 
//        Iterator<Map.Entry> itr1 = address.entrySet().iterator(); 
//        while (itr1.hasNext()) { 
//            Map.Entry pair = itr1.next(); 
//            System.out.println(pair.getKey() + " : " + pair.getValue()); 
//        } 
//          
//        // getting phoneNumbers 
//        JSONArray ja = (JSONArray) jo.get("phoneNumbers"); 
//          
//        // iterating phoneNumbers 
//        Iterator itr2 = ja.iterator(); 
//          
//        while (itr2.hasNext())  
//        { 
//            itr1 = ((Map) itr2.next()).entrySet().iterator(); 
//            while (itr1.hasNext()) { 
//                Map.Entry pair = itr1.next(); 
//                System.out.println(pair.getKey() + " : " + pair.getValue()); 
//            } 
//        }
	    
	    
	    
	    ///
	    
//		answersClass myclass= new Gson().fromJson("jkjkj",answersClass.class);
//		System.out.println(myclass.getID());
		
////		Gson gson = new Gson();
//		answersClass = new Gson().fromJson("hjhjh",answersClass.class);
//		System.out.println(myclass.getID());
		
//		JSONObject obj = new JSONObject();
//		JSONObject obj = new JSONObject.get("Youtube Data"); //this line hopefully should work
//		JSONObject firstItem = obj.getJSONObject("response").getJSONArray("items").getJSONObject(0);
//		System.out.println(firstItem.getInt("id"));
		
//		JSONObject obj = new JSONObject("bhb");
//		JSONObject firstItem = obj.getJSONObject("response").getJSONArray("items").getJSONObject(0);
//		System.out.println(firstItem.getInt("id"));
		
//		PageInfo pageInfo = JsonPath.parse(jsonString).read("$.pageInfo", PageInfo.class);
		
		
//		JSONParser jsonParser = new JSONParser();
//		JSONObject obj = (JSONObject) jsonParser.parse("jkjk");
//		//String product = (String) JSONObject.toString("hjh", "productId");//.escape("productId");//jsonObject.get("productId");
//		
//		static String product = (String) JSONObject.get("productId");
				
//		<dependency>
//	    <groupId>com.jayway.jsonpath</groupId>
//	    <artifactId>json-path</artifactId>
//	    <version>2.3.0</version>
//	</dependency>
	
	
//		BufferedReader br = new BufferedReader(new FileReader("D:\\sampleJson.txt"));
//
//        StringBuilder sb = new StringBuilder();
//        String line = br.readLine();
//
//        while (line != null) {
//            sb.append(line);
//            sb.append(System.lineSeparator());
//            line = br.readLine();
//        }
//        br.close();
//        String jsonInput = sb.toString();
//        
//        Object document = Configuration.defaultConfiguration().jsonProvider().parse(jsonInput);
//        Object document = Configuration.jsonProvider().parse(jsonInput);
//        
//        String pageName = JSONPATH.read(document, "$.pageInfo.pageName");
//        String pagePic = JsonPath.read(document, "$.pageInfo.pagePic");
//        String post_id = JsonPath.read(document, "$.posts[0].post_id");
//
//        System.out.println("$.pageInfo.pageName " + pageName);
//        System.out.println("$.pageInfo.pagePic " + pagePic);
//        System.out.println("$.posts[0].post_id " + post_id);
        
        
        //
        
		//JSONArray a = (JSONArray) parser.parse(new FileReader("c:\\exer4-courses.json"));
		//JSONArray a = (JSONArray) parser.parse(new FileReader("c:\\exer4-courses.json"));
//		JSONArray a = new JSONArray()..parse(new FileReader("c:\\exer4-courses.json"));
		
//		JSONArray a = new JSONArray().parse(new FileReader("c:\\exer4-courses.json"));
//		JSONArray b = new JSONArray().toArray(a);
		
		//JsonObject jsonObject = new JSONParser().parse("{\"name\": \"John\"}")//.getAsJsonObject();
		
//		JSONObject obj = new JSONObject("trtrt");
//		String pageName = obj.getJSONObject("pageInfo").getString("pageName");
//
//		JSONArray arr = obj.getJSONArray("posts");
//		for (int i = 0; i < arr.length(); i++)
//		{
//		    String post_id = arr.get//arr.getJSONObject(i).getString("post_id");
//		    ......etc
//		}
		
//		  for (Object o : a) {
//		    JSONObject person = (JSONObject) o;
//
//		    String name = (String) person.get("name");
//		    System.out.println(name);
//
//		    String city = (String) person.get("city");
//		    System.out.println(city);
//
//		    String job = (String) person.get("job");
//		    System.out.println(job);
//
//		    JSONArray cars = (JSONArray) person.get("cars");
//
//		    for (Object c : cars) {
//		      System.out.println(c+"");
//		    }
//		  }
	}
	
	

		
	public void Run() {
		String text = textField.getText();

		ReadAnswerFile();
		
		if (text.contains("help")) {
			
		} else if (text.contains("goj")) {
			
		} else if (text.contains("cd")) {
			
		}
		// switch statement with int data type 
        switch (level) { 
        case 1: 
        	
            break; 
        case 2: 
        	
            break; 
        case 3: 
        	
            break; 
        case 4: 
        	
            break; 
        case 5: 
        	
            break; 
        case 6: 
        	
            break; 
        case 7: 
        	
            break; 
        case 8: 
        	
            break; 
        case 9: 
        	
            break; 
        case 10: 
        	
            break; 
        default: 
        	
            break; 
        } 
	}
}

